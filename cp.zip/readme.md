CF Tool is a project where a user can view the contests, problems of codeforces. 

They can track their practices also.