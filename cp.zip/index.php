<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Codeforces Problems</title>
    <link rel="stylesheet" href="./css/nav.css">


</head>
<body>
    <?php include './shared/nav.php'; ?>
    <h1>Welcome to Codeforces Problems</h1>
    <p><a href="./problems/allProblems.php">View Codeforces Problems</a></p>
</body>

<!-- <script src="./js/navbar.js"></script> -->
</html>
